# Research Agent Skill

Deep research automation for content creators, analysts, and knowledge workers.

## When to Use This Skill

- **Content Research**: Preparing blog posts, reports, social media content
- **Competitive Analysis**: Understanding market landscape
- **Trend Tracking**: Staying current on fast-moving topics
- **Due Diligence**: Quick but thorough topic exploration

## What Makes This Different

| Feature | Traditional Search | Research Agent |
|---------|-------------------|----------------|
| Results | 10 blue links | Synthesized report |
| Reading | Click each link | Summarized content |
| Output | Raw results | Structured markdown |
| Sources | Manual tracking | Auto-cited |

## Quick Start

### 1. Install

```bash
git clone https://github.com/nikolajflojgaard/research-agent.git
cd research-agent
pip install -r requirements.txt
```

### 2. Configure

```bash
export BRAVE_API_KEY="your_key"
export OPENAI_API_KEY="your_key"  # Optional
```

Get Brave API key: https://brave.com/search/api/

### 3. Run

```bash
python src/research.py "your research topic"
```

## Usage Examples

### Basic Research
```bash
python src/research.py "quantum computing 2024"
```

Output: `~/.openclaw/research/research_quantum_computing_2024_YYYYMMDD_HHMMSS.md`

### Deep Research
```bash
python src/research.py "AI agent frameworks" --deep
```
- 20 sources instead of 10
- More comprehensive synthesis

### Focused Research
```bash
python src/research.py "Tesla FSD" --focus "safety statistics"
```
- Narrows search to specific angle

### Custom Output
```bash
python src/research.py "Web3 trends" --output ./reports/web3.md
```

## Output Format

```markdown
# Research: [Topic]

*Generated: YYYY-MM-DD HH:MM*

## Executive Summary
2-3 sentence overview of findings

## Key Insights
- Insight 1 (with implication)
- Insight 2 (with implication)
- Contrarian viewpoint (if found)

## Trends Identified
- Trend 1
- Trend 2

## Knowledge Gaps
What couldn't be found or needs verification

## Sources
1. [Title](url) — Source type
2. [Title](url) — Source type
...
```

## Integration Patterns

### With OpenClaw Main Session

```python
from skills.research_agent import ResearchAgent

agent = ResearchAgent()
report = agent.research("Topic for today's content")
# Use report in your content generation
```

### As Sub-Agent

Spawn isolated research session for heavy queries.

### In Cron Jobs

```bash
# Daily research on trending topics
0 9 * * * python src/research.py "today's trending topic" --deep
```

## Best Practices

1. **Specific Topics**: "AI agents" → "AI agent frameworks comparison 2024"
2. **Iterate**: Start shallow, go deep on promising angles
3. **Verify**: Cross-check critical claims across sources
4. **Credit**: Always cite sources in final content

## Limitations

- Requires API keys for full functionality
- Web extraction can fail on complex sites
- Not a replacement for deep expert research
- News sources limited by Brave's index

## Extending

Add custom search sources:

```python
def search_academic(self, query):
    # Add arXiv, Google Scholar integration
    pass

def search_reddit(self, query):
    # Add Reddit discussions
    pass
```

## License

MIT — Free to use and modify.
