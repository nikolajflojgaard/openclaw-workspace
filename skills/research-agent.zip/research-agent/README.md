# OpenClaw Research Agent

> Deep research automation for content creators, analysts, and knowledge workers.

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 🎯 What Makes This Different

| Traditional Search | Research Agent |
|-------------------|----------------|
| 10 blue links | Synthesized report |
| Click each link | Summarized content |
| Manual tracking | Auto-cited sources |
| Raw results | Structured markdown |
| Single source | Multi-source synthesis |

## 🚀 Quick Start

### Installation

```bash
# Clone repository
git clone https://github.com/nikolajflojgaard/openclaw-research-agent.git
cd openclaw-research-agent

# Install dependencies
pip install -r requirements.txt

# Configure API keys
cp .env.example .env
# Edit .env with your keys
```

### API Keys Required

**Brave Search API** (Required)
- Get key: https://brave.com/search/api/
- Free tier: 2,000 queries/month

**OpenAI API** (Optional)
- For AI-powered synthesis
- Can run without (basic synthesis)

## 📖 Usage

### Basic Research

```bash
python src/research.py "quantum computing breakthroughs 2024"
```

Output: `~/.openclaw/research/research_quantum_computing_2024_YYYYMMDD_HHMMSS.md`

### Deep Research

```bash
python src/research.py "AI agent frameworks" --deep --focus "comparison"
```

- 20 sources instead of 10
- More comprehensive synthesis
- Focused on specific angle

### Batch Research

```bash
python src/batch_research.py topics.txt
```

`topics.txt`:
```
Tesla FSD vs Waymo
Quantum computing startups
AI regulation Europe
```

### Custom Output

```bash
python src/research.py "Web3 trends" --output ./reports/web3.md --format academic
```

## 🎨 Output Formats

### Standard (default)
```markdown
# Research: Topic

## Executive Summary
Brief overview

## Key Insights
- Point 1 [Source]
- Point 2 [Source]

## Sources
1. [Title](url)
```

### Academic
```markdown
# Research Report: Topic

## Abstract
## Literature Review
## Key Findings
## Methodology
## References
```

### Social Media
```markdown
# Content Ideas: Topic

## Hook Ideas
## Thread Concepts
## Quote Opportunities
## Source Material
```

## ⚙️ Configuration

### Environment Variables

```bash
# Required
BRAVE_API_KEY=your_brave_key

# Optional (for AI synthesis)
OPENAI_API_KEY=your_openai_key

# Optional (customization)
RESEARCH_CACHE_DIR=~/.openclaw/research
RESEARCH_MAX_RESULTS=10
RESEARCH_TIMEOUT=30
```

### Config File

Create `~/.openclaw/research/config.json`:

```json
{
  "default_depth": "standard",
  "default_format": "standard",
  "cache_enabled": true,
  "cache_duration_hours": 24,
  "min_source_credibility": 0.6,
  "preferred_sources": ["news", "academic", "gov"]
}
```

## 🔧 Advanced Features

### Source Credibility Scoring

Automatic vurdering af kilder:
- **High** (0.8-1.0): Reputable news, academic journals, government
- **Medium** (0.5-0.7): Blogs, industry sites, Wikipedia
- **Low** (0.0-0.4): Forums, social media, unknown sites

### Caching

Undgå dobbelt-søgninger:
```python
# Samme søgning indenfor 24 timer = cache hit
agent.research("AI trends")  # Søger
agent.research("AI trends")  # Bruger cache
```

### Rate Limiting

Respekterer API grænser:
- Brave: Max 1 query/sekund
- OpenAI: Max 3 requests/minut (synthesis)

### Logging

Alle søgninger logges:
```
~/.openclaw/research/logs/
├── 2024-01-research.log
├── 2024-02-research.log
└── search-history.json
```

## 🔄 Integration with OpenClaw

### As Skill

```python
from skills.research_agent import ResearchAgent

agent = ResearchAgent()
report = agent.research(
    topic="Today's trending tech",
    depth="deep",
    format="social"
)

# Use in content generation
```

### In Cron Jobs

```bash
# Daily research at 8 AM
0 8 * * * python src/research.py "overnight tech news" --format social
```

### With Other Skills

```python
# Research → Content pipeline
research = agent.research("AI trends")
content = content_agent.create(research, platform="twitter")
scheduler.schedule(content, time="optimal")
```

## 📊 Example Outputs

### Example 1: Tech Research

```bash
$ python src/research.py "Tesla Cybertruck production" --deep

🔍 Researching: Tesla Cybertruck production
   Depth: deep

📡 Searching web... 10 results
📰 Searching news... 10 results
✅ Found 15 unique sources

🧠 Synthesizing findings...
💾 Saved to: ~/.openclaw/research/research_tesla_cybertruck_production_20240223_143022.md

Top findings:
- Production rate: 1,000/week (source: Reuters)
- New variants coming Q2 (source: Electrek)
- 2M+ reservations (source: Tesla)
```

### Example 2: Batch Research

```bash
$ python src/batch_research.py topics.txt --output-dir ./reports/

Processing 3 topics...

✅ AI regulation Europe
   12 sources → ./reports/ai_regulation_europe_20240223.md

✅ Quantum startups
   8 sources → ./reports/quantum_startups_20240223.md

✅ Tesla vs Waymo
   15 sources → ./reports/tesla_vs_waymo_20240223.md

Batch complete: 3/3 successful
```

## 🛠️ Extending

### Add Custom Search Source

```python
def search_reddit(self, query: str):
    """Add Reddit discussions."""
    # Implementation
    pass

def search_arxiv(self, query: str):
    """Add academic papers."""
    # Implementation
    pass
```

### Custom Output Template

```python
TEMPLATE_EXECUTIVE = """
# Executive Brief: {topic}

## Bottom Line
{summary}

## Action Items
{actions}

## Risks
{risks}

## Sources
{sources}
"""
```

## 📝 Best Practices

1. **Specific Queries**
   - ❌ "AI"
   - ✅ "AI agent frameworks comparison 2024"

2. **Iterate**
   - Start shallow
   - Go deep on promising angles

3. **Verify**
   - Cross-check critical claims
   - Check publication dates

4. **Credit**
   - Always cite sources
   - Link to original content

## 🐛 Troubleshooting

### Common Issues

**"No API key found"**
```bash
export BRAVE_API_KEY="your_key"
# Or add to ~/.bashrc
```

**"Rate limit exceeded"**
- Wait 60 seconds
- Use `--cache` to avoid re-search

**"Empty results"**
- Try broader query
- Check internet connection

## 🤝 Contributing

Contributions welcome! Areas for improvement:
- [ ] Add more search sources (Reddit, HN, arXiv)
- [ ] More output templates
- [ ] Source credibility improvements
- [ ] GUI/web interface
- [ ] Export to Notion/Obsidian

## 📜 License

MIT License — Free to use and modify.

## 🙏 Credits

Built for [OpenClaw](https://openclaw.ai) agent ecosystem.

---

**Need help?** Open an issue or reach out on [Discord](https://discord.gg/openclaw)
