#!/usr/bin/env python3
"""Research Agent — Deep content research with caching and logging."""

import os
import json
import hashlib
import argparse
import time
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import requests
from urllib.parse import urlparse


class ResearchCache:
    """Simple file-based cache for research results."""
    
    def __init__(self, cache_dir: Path, duration_hours: int = 24):
        self.cache_dir = cache_dir / "cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.duration = timedelta(hours=duration_hours)
    
    def _get_key(self, query: str) -> str:
        """Generate cache key from query."""
        return hashlib.md5(query.lower().encode()).hexdigest()
    
    def get(self, query: str) -> Optional[List[Dict]]:
        """Get cached results if not expired."""
        key = self._get_key(query)
        cache_file = self.cache_dir / f"{key}.json"
        
        if not cache_file.exists():
            return None
        
        try:
            with open(cache_file) as f:
                data = json.load(f)
            
            cached_time = datetime.fromisoformat(data["timestamp"])
            if datetime.now() - cached_time < self.duration:
                print(f"   📦 Cache hit for: {query[:50]}...")
                return data["results"]
        except Exception:
            pass
        
        return None
    
    def set(self, query: str, results: List[Dict]):
        """Cache results."""
        key = self._get_key(query)
        cache_file = self.cache_dir / f"{key}.json"
        
        data = {
            "query": query,
            "timestamp": datetime.now().isoformat(),
            "results": results
        }
        
        with open(cache_file, 'w') as f:
            json.dump(data, f)


class ResearchLogger:
    """Log research activities."""
    
    def __init__(self, log_dir: Path):
        self.log_dir = log_dir / "logs"
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.history_file = log_dir / "search_history.json"
    
    def log_search(self, query: str, sources: int, duration: float):
        """Log a search."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "query": query,
            "sources": sources,
            "duration_seconds": round(duration, 2)
        }
        
        # Append to history
        history = []
        if self.history_file.exists():
            try:
                with open(self.history_file) as f:
                    history = json.load(f)
            except:
                pass
        
        history.append(entry)
        
        with open(self.history_file, 'w') as f:
            json.dump(history[-1000:], f)  # Keep last 1000
        
        # Also log to monthly file
        month_key = datetime.now().strftime("%Y-%m")
        month_file = self.log_dir / f"{month_key}-research.log"
        
        with open(month_file, 'a') as f:
            f.write(f"{entry['timestamp']} | {query[:60]:60} | {sources:3} sources | {duration:.1f}s\n")


class SourceCredibility:
    """Score source credibility."""
    
    HIGH_SOURCES = [
        "reuters.com", "bloomberg.com", "wsj.com", "ft.com",
        "nature.com", "science.org", "arxiv.org",
        "gov", "edu", "who.int", "un.org"
    ]
    
    MEDIUM_SOURCES = [
        "techcrunch.com", "theverge.com", "wired.com",
        "medium.com", "substack.com", "github.com",
        "wikipedia.org"
    ]
    
    @classmethod
    def score(cls, url: str) -> float:
        """Score URL credibility 0.0-1.0."""
        domain = urlparse(url).netloc.lower()
        
        # High credibility
        for high in cls.HIGH_SOURCES:
            if high in domain:
                return 0.8 + (0.2 * (1 - len(high) / len(domain)))  # 0.8-1.0
        
        # Medium credibility
        for medium in cls.MEDIUM_SOURCES:
            if medium in domain:
                return 0.5 + (0.3 * (1 - len(medium) / len(domain)))  # 0.5-0.8
        
        # Low credibility (forums, social, unknown)
        low_indicators = ["forum", "reddit", "facebook", "twitter", "blog"]
        if any(ind in domain for ind in low_indicators):
            return 0.3
        
        # Unknown
        return 0.5


class ResearchAgent:
    """AI-powered research agent for deep content research."""
    
    def __init__(self):
        self.brave_key = os.environ.get("BRAVE_API_KEY", "")
        self.openai_key = os.environ.get("OPENAI_API_KEY", "")
        self.results_dir = Path.home() / ".openclaw" / "research"
        self.results_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize cache and logger
        self.cache = ResearchCache(self.results_dir)
        self.logger = ResearchLogger(self.results_dir)
        
        # Rate limiting
        self.last_request_time = 0
        self.min_request_interval = 1.0  # 1 second between requests
    
    def _rate_limit(self):
        """Enforce rate limiting."""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.min_request_interval:
            time.sleep(self.min_request_interval - elapsed)
        self.last_request_time = time.time()
    
    def search_web(self, query: str, count: int = 10) -> List[Dict[str, Any]]:
        """Search web using Brave Search API."""
        # Check cache first
        cached = self.cache.get(query)
        if cached:
            return cached
        
        if not self.brave_key:
            print("⚠️  No BRAVE_API_KEY found. Set it in .env file.")
            return []
        
        self._rate_limit()
        
        url = "https://api.search.brave.com/res/v1/web/search"
        headers = {
            "X-Subscription-Token": self.brave_key,
            "Accept": "application/json"
        }
        params = {
            "q": query,
            "count": count,
            "freshness": "pw"  # Past week for more results
        }
        
        try:
            resp = requests.get(url, headers=headers, params=params, timeout=30)
            if resp.status_code == 200:
                data = resp.json()
                results = []
                for item in data.get("web", {}).get("results", []):
                    url = item.get("url", "")
                    results.append({
                        "title": item.get("title"),
                        "url": url,
                        "description": item.get("description"),
                        "age": item.get("age"),
                        "source": "web",
                        "credibility": SourceCredibility.score(url)
                    })
                
                # Cache results
                self.cache.set(query, results)
                return results
            else:
                print(f"⚠️  Search API error: {resp.status_code}")
        except Exception as e:
            print(f"⚠️  Search error: {e}")
        
        return []
    
    def search_news(self, query: str, count: int = 10) -> List[Dict[str, Any]]:
        """Search news using Brave News API."""
        if not self.brave_key:
            return []
        
        self._rate_limit()
        
        url = "https://api.search.brave.com/res/v1/news/search"
        headers = {
            "X-Subscription-Token": self.brave_key,
            "Accept": "application/json"
        }
        params = {
            "q": query,
            "count": count,
            "freshness": "pw"
        }
        
        try:
            resp = requests.get(url, headers=headers, params=params, timeout=30)
            if resp.status_code == 200:
                data = resp.json()
                results = []
                for item in data.get("results", []):
                    url = item.get("url", "")
                    results.append({
                        "title": item.get("title"),
                        "url": url,
                        "description": item.get("description"),
                        "age": item.get("age"),
                        "source": "news",
                        "credibility": SourceCredibility.score(url) + 0.1  # News slightly higher
                    })
                return results
        except Exception as e:
            print(f"⚠️  News search error: {e}")
        
        return []
    
    def synthesize(self, topic: str, findings: List[Dict]) -> str:
        """Synthesize findings into markdown report."""
        if not self.openai_key:
            return self._basic_synthesis(topic, findings)
        
        return self._ai_synthesis(topic, findings)
    
    def _basic_synthesis(self, topic: str, findings: List[Dict]) -> str:
        """Create basic markdown without AI."""
        # Sort by credibility
        findings = sorted(findings, key=lambda x: x.get("credibility", 0), reverse=True)
        
        lines = [
            f"# Research: {topic}",
            "",
            f"*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}*",
            f"*Sources: {len(findings)}*",
            "",
            "## Executive Summary",
            f"Found {len(findings)} relevant sources on {topic}.",
            "",
            "## Top Sources by Credibility",
            ""
        ]
        
        for i, finding in enumerate(findings[:10], 1):
            cred = finding.get("credibility", 0.5)
            cred_emoji = "🟢" if cred >= 0.8 else "🟡" if cred >= 0.6 else "🟠"
            lines.append(f"{i}. {cred_emoji} **[{finding.get('title', 'Untitled')}]({finding.get('url')})**")
            lines.append(f"   - {finding.get('description', 'No description')[:150]}...")
            lines.append(f"   - Credibility: {cred:.2f} | Source: {finding.get('source', 'unknown')}")
            lines.append("")
        
        lines.extend([
            "## All Sources",
            ""
        ])
        
        for i, finding in enumerate(findings, 1):
            lines.append(f"{i}. [{finding.get('title', 'Link')}]({finding.get('url')})")
        
        lines.extend([
            "",
            "---",
            "",
            "*Generated by OpenClaw Research Agent*"
        ])
        
        return '\n'.join(lines)
    
    def _ai_synthesis(self, topic: str, findings: List[Dict]) -> str:
        """Use OpenAI for advanced synthesis."""
        # Sort by credibility and take top 5
        findings = sorted(findings, key=lambda x: x.get("credibility", 0), reverse=True)
        top_findings = findings[:5]
        
        context = "\n\n".join([
            f"Source {i+1} (Credibility: {f.get('credibility', 0.5):.2f}): {f.get('title')}\n{f.get('description')[:300]}"
            for i, f in enumerate(top_findings)
        ])
        
        prompt = f"""Synthesize research on "{topic}" into a structured markdown report.

Sources (sorted by credibility):
{context}

Create a report with:
1. Executive summary (2-3 sentences with key takeaway)
2. Key insights (3-5 bullet points with evidence)
3. Contrarian or alternative viewpoints (if any)
4. Confidence level (High/Medium/Low) with reasoning

Format as clean markdown. Be objective and cite uncertainty where appropriate."""
        
        try:
            self._rate_limit()
            
            resp = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.openai_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "gpt-4o-mini",
                    "messages": [
                        {"role": "system", "content": "You are a research analyst. Create structured, objective reports with appropriate uncertainty."},
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": 0.3,
                    "max_tokens": 1500
                },
                timeout=60
            )
            
            if resp.status_code == 200:
                data = resp.json()
                synthesis = data["choices"][0]["message"]["content"]
                
                # Add metadata and sources
                header = f"""# Research: {topic}

*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}*
*Sources: {len(findings)}*
*Synthesis: AI-powered*

"""
                
                sources_md = "\n\n## All Sources\n\n"
                for i, f in enumerate(findings, 1):
                    cred = f.get("credibility", 0.5)
                    emoji = "🟢" if cred >= 0.8 else "🟡" if cred >= 0.6 else "🟠"
                    sources_md += f"{i}. {emoji} [{f.get('title', 'Link')}]({f.get('url')}) — {f.get('source')} (cred: {cred:.2f})\n"
                
                footer = "\n\n---\n\n*Generated by OpenClaw Research Agent*"
                
                return header + synthesis + sources_md + footer
        except Exception as e:
            print(f"⚠️  AI synthesis error: {e}")
        
        return self._basic_synthesis(topic, findings)
    
    def _timestamp(self) -> str:
        """Generate timestamp string."""
        return datetime.now().strftime("%Y%m%d_%H%M%S")
    
    def research(self, topic: str, depth: str = "standard", focus: str = None, 
                 output_dir: Path = None) -> Dict:
        """Main research function."""
        start_time = time.time()
        
        print(f"🔍 Researching: {topic}")
        print(f"   Depth: {depth}")
        if focus:
            print(f"   Focus: {focus}")
        
        # Build query
        query = topic
        if focus:
            query = f"{topic} {focus}"
        
        # Search
        print("\n📡 Searching web...")
        web_results = self.search_web(query, count=10 if depth == "deep" else 5)
        
        print("📰 Searching news...")
        news_results = self.search_news(query, count=10 if depth == "deep" else 5)
        
        # Combine and deduplicate
        all_results = web_results + news_results
        seen_urls = set()
        unique_results = []
        for r in all_results:
            if r["url"] not in seen_urls:
                seen_urls.add(r["url"])
                unique_results.append(r)
        
        duration = time.time() - start_time
        print(f"\n✅ Found {len(unique_results)} unique sources in {duration:.1f}s")
        
        # Log the search
        self.logger.log_search(topic, len(unique_results), duration)
        
        # Synthesize
        print("🧠 Synthesizing findings...")
        report = self.synthesize(topic, unique_results)
        
        # Save
        out_dir = output_dir or self.results_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        
        timestamp = self._timestamp()
        safe_topic = "".join(c if c.isalnum() else "_" for c in topic[:30])
        filename = f"research_{safe_topic}_{timestamp}.md"
        filepath = out_dir / filename
        
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(report)
        
        print(f"\n💾 Saved to: {filepath}")
        
        return {
            "topic": topic,
            "sources": unique_results,
            "report": report,
            "filepath": str(filepath),
            "duration": duration
        }


def main():
    parser = argparse.ArgumentParser(
        description="Research Agent — Deep content research",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python src/research.py "quantum computing 2024"
  python src/research.py "AI agents" --deep --focus "comparison"
  python src/research.py "Tesla FSD" --output ./reports/tesla.md
        """
    )
    parser.add_argument("topic", help="Research topic")
    parser.add_argument("--deep", action="store_true", help="Deep research (more sources)")
    parser.add_argument("--focus", help="Specific focus area")
    parser.add_argument("--output", help="Output file path")
    parser.add_argument("--format", choices=["standard", "academic", "social"], 
                       default="standard", help="Output format")
    
    args = parser.parse_args()
    
    agent = ResearchAgent()
    depth = "deep" if args.deep else "standard"
    
    result = agent.research(args.topic, depth=depth, focus=args.focus)
    
    print("\n" + "="*80)
    print("RESEARCH REPORT PREVIEW")
    print("="*80)
    print(result["report"][:2000])
    print("\n... [truncated for display] ...")
    print(f"\nFull report: {result['filepath']}")
    print(f"Sources: {len(result['sources'])}")
    print(f"Duration: {result['duration']:.1f}s")


if __name__ == "__main__":
    main()
