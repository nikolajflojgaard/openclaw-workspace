#!/usr/bin/env python3
"""Batch Research — Process multiple topics at once."""

import argparse
import sys
from pathlib import Path
from typing import List

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from research import ResearchAgent


def read_topics_file(filepath: str) -> List[str]:
    """Read topics from file (one per line)."""
    topics = []
    try:
        with open(filepath, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    topics.append(line)
    except FileNotFoundError:
        print(f"Error: File not found: {filepath}")
        sys.exit(1)
    return topics


def main():
    parser = argparse.ArgumentParser(
        description="Batch Research — Process multiple topics"
    )
    parser.add_argument(
        "topics_file",
        help="File containing topics (one per line)"
    )
    parser.add_argument(
        "--output-dir",
        default="./reports",
        help="Output directory for reports"
    )
    parser.add_argument(
        "--depth",
        choices=["standard", "deep"],
        default="standard",
        help="Research depth"
    )
    parser.add_argument(
        "--format",
        choices=["standard", "academic", "social", "executive"],
        default="standard",
        help="Output format"
    )
    parser.add_argument(
        "--delay",
        type=int,
        default=5,
        help="Seconds between requests (rate limiting)"
    )
    
    args = parser.parse_args()
    
    # Read topics
    topics = read_topics_file(args.topics_file)
    if not topics:
        print("Error: No topics found in file")
        sys.exit(1)
    
    print(f"📚 Batch Research: {len(topics)} topics")
    print(f"   Depth: {args.depth}")
    print(f"   Format: {args.format}")
    print(f"   Output: {args.output_dir}")
    print()
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Process each topic
    agent = ResearchAgent()
    results = []
    
    for i, topic in enumerate(topics, 1):
        print(f"\n{'='*60}")
        print(f"Topic {i}/{len(topics)}: {topic}")
        print('='*60)
        
        try:
            report = agent.research(
                topic=topic,
                depth=args.depth,
                output_dir=output_dir
            )
            results.append({
                "topic": topic,
                "status": "success",
                "sources": len(report.get("sources", []))
            })
            print(f"✅ Success: {topic[:50]}...")
            
        except Exception as e:
            print(f"❌ Error: {e}")
            results.append({
                "topic": topic,
                "status": "error",
                "error": str(e)
            })
        
        # Rate limiting
        if i < len(topics) and args.delay > 0:
            print(f"   Waiting {args.delay}s...")
            import time
            time.sleep(args.delay)
    
    # Summary
    print(f"\n{'='*60}")
    print("BATCH SUMMARY")
    print('='*60)
    
    success = sum(1 for r in results if r["status"] == "success")
    failed = sum(1 for r in results if r["status"] == "error")
    
    print(f"\n✅ Successful: {success}/{len(topics)}")
    print(f"❌ Failed: {failed}/{len(topics)}")
    
    if failed > 0:
        print("\nFailed topics:")
        for r in results:
            if r["status"] == "error":
                print(f"  - {r['topic']}: {r.get('error', 'Unknown error')}")
    
    print(f"\n📁 Reports saved to: {output_dir}")
    
    # Save summary
    summary_file = output_dir / f"batch_summary_{agent._timestamp()}.txt"
    with open(summary_file, 'w') as f:
        f.write("Batch Research Summary\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Total topics: {len(topics)}\n")
        f.write(f"Successful: {success}\n")
        f.write(f"Failed: {failed}\n\n")
        f.write("Results:\n")
        for r in results:
            status = "✅" if r["status"] == "success" else "❌"
            f.write(f"{status} {r['topic']}\n")
    
    print(f"📝 Summary: {summary_file}")


if __name__ == "__main__":
    main()
